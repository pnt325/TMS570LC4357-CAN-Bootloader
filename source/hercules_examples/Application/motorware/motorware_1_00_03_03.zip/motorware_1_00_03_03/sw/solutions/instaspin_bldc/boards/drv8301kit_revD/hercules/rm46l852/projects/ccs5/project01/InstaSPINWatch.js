// CCS Watch Window JavaScript
// InstaSPINWatch.js

expAdd ("gGUIObj.EnableFlg");
expAdd ("gDRVObj.isrTicker");
expAdd ("gGUIObj.LogScalar");
expAdd ("gGUIObj.SpdMotor");
expAdd ("gGUIObj.SpeedRPM");
expAdd ("gGUIObj.DFuncStartup");
expAdd ("gDRVObj.instaHandle->vaOffset");
expAdd ("gDRVObj.instaHandle->vbOffset");
expAdd ("gDRVObj.instaHandle->vcOffset");
expAdd ("gGUIObj.DutyCmd");
expAdd ("gGUIObj.TorqueCmd");
expAdd ("gGUIObj.SpdCmd");
expAdd ("gGUIObj.CtrlType");