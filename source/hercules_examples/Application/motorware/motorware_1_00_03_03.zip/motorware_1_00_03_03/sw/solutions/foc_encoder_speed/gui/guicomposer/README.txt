

All the webapps files are to be installed in the guicomposer runtime directory. This is
typically C:/ti/guicomposer/webapps.
